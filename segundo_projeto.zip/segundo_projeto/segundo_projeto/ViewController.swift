//
//  ViewController.swift
//  segundo_projeto
//
//  Created by Administrador on 09/03/19.
//  Copyright © 2019 Administrador. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Label: UILabel!
    
    @IBOutlet weak var textUsuario: UITextField!
    
    @IBOutlet weak var textSenha: UITextField!
    
    @IBAction func Pressionar(_ sender: Any) {
        print("Nome digitado:\(textUsuario.text!)")
        }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

