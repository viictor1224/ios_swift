//
//  ViewController.swift
//  projeto05
//
//  Created by Alunos e Professores on 30/03/19.
//  Copyright © 2019 Alunos e Professores. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageDice1: UIImageView!
    
    @IBOutlet weak var imageDice2: UIImageView!
    

    @IBAction func VirusGenerator(_ sender: Any) {
//        let dices = ["dice1", "dice2"]
        rodarVirus()
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        rodarVirus()
    }
    
    func rodarVirus() {
        let dice1random = Int(arc4random_uniform(6)) + 1
        let dice2random = Int(arc4random_uniform(6)) + 1
        imageDice1.image = UIImage(named:"dice\(dice1random)")
        imageDice2.image = UIImage(named:"dice\(dice2random)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

